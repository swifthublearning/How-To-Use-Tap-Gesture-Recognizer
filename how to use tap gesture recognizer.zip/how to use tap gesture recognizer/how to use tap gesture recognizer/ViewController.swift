//
//  ViewController.swift
//  how to use tap gesture recognizer
//
//  Created by Supine Hub Technologies Pvt. Ltd. on 09/03/20.
//  Copyright © 2020 Supine Hub Technologies Pvt. Ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let TapGesture = UITapGestureRecognizer()
        self.view.addGestureRecognizer(TapGesture)
        TapGesture.addTarget(self, action: #selector(tapclick))
    }
    
    @objc func tapclick()
    {
        print("Click Tap Gesture On Screen")
    }

    @IBAction func clicktapgestureimage(_ sender: Any) {
        print("Click Image Tap Gesture Successfully")
    }
    
}

